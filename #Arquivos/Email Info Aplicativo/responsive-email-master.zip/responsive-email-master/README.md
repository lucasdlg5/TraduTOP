Responsive Email
================
The basic "responsive" email template.

![Simple Template](/images/simple-template.png?raw=true)

**Setup**

1. Copy contents of `simple.css`.
2. Paste inline inside `<style>` tag.
3. Pass through inliner utility like [Inliner by Zurb](http://zurb.com/ink/inliner.php).
